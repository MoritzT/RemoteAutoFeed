# Changelog

## v1.0

- Production release candidate based on the validated v0.13 architecture.
- Keeps 90% normalized recovery target.
- Keeps concrete ApproachToFoodBox cancellation and StopMovement.
- Keeps Palworld-native RequestUseToCharacter food consumption.
- Keeps per-feed-box meal serialization.
- Uses the individual Pal's FullStomach increase as authoritative bite proof.
- Adds compact production meal logging:
  `Pal`, `items`, fullness before/after, target and completion status.
- Moves target retries, per-bite data, queue activity and hook details behind
  `DebugLogging`.
- Warnings/errors remain enabled regardless of debug setting.
- Adds delayed cleanup of completed RecoverHungry root state for long-running
  dedicated servers.
