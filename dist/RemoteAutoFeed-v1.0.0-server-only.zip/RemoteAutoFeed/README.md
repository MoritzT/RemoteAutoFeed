# RemoteAutoFeed v1.0

Dedicated-server-only UE4SS Lua mod for Palworld 1.0.

Base Pals use the food selected from their vanilla feed box without walking to
the box. No client installation is required.

## Behavior

When Palworld starts the vanilla RecoverHungry -> ApproachToFoodBox flow:

1. RemoteAutoFeed lets Palworld initialize and select the actual feed box.
2. The concrete ApproachToFoodBox movement is cancelled.
3. The hungry Pal's real `FPalInstanceID` is resolved.
4. The selected feed-box container is used.
5. Food is consumed with Palworld's own:
       RequestUseToCharacter(PalInstanceID, 1)
6. Each bite is verified by checking that this Pal's `FullStomach` increased.
7. Feeding continues until the configured percentage of that Pal's own
   `GetMaxFullStomach()` is reached, while respecting EatMaxNum.
8. The RecoverHungry action ends and the Pal continues working.

No direct food-stack edits and no direct satiety edits are performed.

## Default recovery target

    TargetSatietyPercent = 0.90

A Pal is therefore fed to at least 90% of its own maximum stomach capacity.

Whole food items can overshoot the target. For example, a Pal at 89.9% that
eats a berry may finish near 100%. That is intentional.

## Production logging

By default:

    MealLogging = true
    DebugLogging = false

This emits one lightweight line per meal, for example:

    [RemoteAutoFeed] MEAL | Pal=BP_Serpent_C | items=5 | fullness=50.0%->99.9% | target=90.0% | status=complete

This makes it easy to confirm:
- which Pal ate,
- how many food items it consumed,
- its fullness before and after,
- the configured target.

Warnings and errors are always logged.

## Detailed debugging

For troubleshooting:

    DebugLogging = true

This additionally logs:
- hook registration,
- feed-box target initialization/retries,
- movement cancellation,
- feed-box queue/lock activity,
- every remote bite,
- stack diagnostics,
- per-bite FullStomach verification,
- Approach re-entry suppression.

Leave it `false` for normal server operation.

## Concurrency

Remote meals are serialized per physical feed-box container. If several Pals
become hungry at once and use the same box, only one complete meal manipulates
that container at a time.

Different feed boxes can still operate concurrently.

`FullStomach` on the specific Pal is the authoritative success check. Feed-box
stack changes are debug information only because another Pal can also consume
from the same inventory.

## Safety / fallback

RemoteAutoFeed does not:
- directly modify StackCount,
- directly modify FullStomach,
- add replicated classes,
- add custom RPCs,
- require client UE4SS,
- require client assets or UI.

Before movement is cancelled, the mod must successfully resolve the vanilla
feed-box target, container, Pal instance ID, maximum stomach and recovery
parameters. Setup failures leave vanilla feeding available and emit a warning.

## Installation

Extract so the server has:

    ue4ss/
    └── Mods/
        └── RemoteAutoFeed/
            ├── enabled.txt
            ├── README.md
            ├── CHANGELOG.md
            └── Scripts/
                ├── config.lua
                └── main.lua

Fully restart the dedicated server after replacing the mod.

## Tested behavior during development

The 1.0 implementation was validated with Pals having different stomach
capacities, including 100, 140 and 210 maximum FullStomach values.

Observed behavior included:
- no visible trip to the feed box,
- hunger icon appearing briefly and disappearing,
- real feed-box items being consumed,
- Pal FullStomach increasing after every verified bite,
- recovery to at least 90%,
- simultaneous hungry Pals handled safely,
- vanilla clients requiring no mod.
